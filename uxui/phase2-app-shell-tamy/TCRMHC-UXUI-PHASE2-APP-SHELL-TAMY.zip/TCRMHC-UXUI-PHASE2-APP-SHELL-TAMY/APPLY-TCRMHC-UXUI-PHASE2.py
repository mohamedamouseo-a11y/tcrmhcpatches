#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import shutil
import subprocess

ROOT = Path.cwd()
BASE_COMMIT = "1910167e64182cfd0df7f2fcb2afe725cc4134ac"
MARKER = '/* TCRMHC UX/UI Phase 2 — Application Shell + Tamy Floating Agent */'
PHASE11_MARKER = "/* TCRMHC UX/UI Phase 1.1 — Light Login Contrast Fix */"

ADMIN = ROOT / "apps/web/src/features/admin/AdminLayout.tsx"
TAMY = ROOT / "apps/web/src/features/TamyFloatingAgent.tsx"
STYLES = ROOT / "apps/web/src/styles.css"

ADMIN_CONTENT = r"""import { useEffect, useMemo, useState, type ReactNode } from "react";
import type { SessionUser } from "../../lib/api-client";
import type { Language } from "../../i18n/translations";
import { ThemeToggle } from "../ThemeToggle";
import { TamyFloatingAgent } from "../TamyFloatingAgent";

const adminItems = [
  ["/app", "لوحة التحكم", "Dashboard"],
  ["/app/tenants", "العملاء", "Customers"],
  ["/app/users", "المستخدمون", "Users"],
  ["/app/positions", "المناصب", "Positions"],
  ["/app/sessions", "الجلسات", "Sessions"],
  ["/app/security-events", "سجل الأمان", "Security Events"],
  ["/app/knowledge", "قاعدة المعرفة", "Knowledge Base"],
  ["/app/developer-hub", "مركز المطورين", "Developer Hub"]
] as const;

const helpItems = [["/app/help", "مركز المساعدة", "Help Center"]] as const;

const knowledgeItems = [
  ["/app/knowledge/audiences", "جمهور المساعدة", "Help Audiences"],
  ["/app/knowledge/docs", "تغييرات التوثيق", "Documentation changes"],
  ["/app/knowledge/modules", "الوحدات", "Modules"],
  ["/app/knowledge/categories", "التصنيفات", "Categories"],
  ["/app/knowledge/subcategories", "التصنيفات الفرعية", "Subcategories"],
  ["/app/knowledge/articles", "المقالات", "Articles"]
] as const;

function pathActive(current: string, href: string) {
  return current === href || (href !== "/app" && current.startsWith(`${href}/`));
}

export function AdminLayout({
  user,
  lang,
  setLang,
  onLogout,
  children,
  isSuperadmin
}: {
  user: SessionUser;
  lang: Language;
  setLang: (lang: Language) => void;
  onLogout: () => void;
  children: ReactNode;
  isSuperadmin: boolean;
}) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const current = window.location.pathname;
  const items = isSuperadmin ? adminItems : helpItems;

  const currentTitle = useMemo(() => {
    const candidates = [...items].sort((a, b) => b[0].length - a[0].length);
    const match = candidates.find(([href]) => pathActive(current, href));
    if (!match) return lang === "ar" ? "مركز المساعدة" : "Help Center";
    return lang === "ar" ? match[1] : match[2];
  }, [current, items, lang]);

  useEffect(() => {
    document.body.classList.toggle("admin-nav-open", mobileNavOpen);
    return () => document.body.classList.remove("admin-nav-open");
  }, [mobileNavOpen]);

  useEffect(() => {
    const closeOnDesktop = () => {
      if (window.innerWidth > 980) setMobileNavOpen(false);
    };
    window.addEventListener("resize", closeOnDesktop);
    return () => window.removeEventListener("resize", closeOnDesktop);
  }, []);

  const closeMobileNav = () => setMobileNavOpen(false);

  return (
    <div className={`admin-shell${mobileNavOpen ? " mobile-nav-open" : ""}`}>
      <button
        className="admin-sidebar-scrim"
        type="button"
        aria-label={lang === "ar" ? "إغلاق القائمة" : "Close navigation"}
        onClick={closeMobileNav}
      />

      <aside className={`admin-sidebar${mobileNavOpen ? " mobile-open" : ""}`} aria-label={lang === "ar" ? "التنقل الرئيسي" : "Main navigation"}>
        <div className="admin-sidebar-head">
          <a href={isSuperadmin ? "/app" : "/app/help"} className="admin-brand" onClick={closeMobileNav}>
            <img src="/assets/tcrm-logo.png" alt="TCRM Help Center" />
            <span>HELP CENTER</span>
          </a>
          <button
            className="admin-sidebar-close"
            type="button"
            onClick={closeMobileNav}
            aria-label={lang === "ar" ? "إغلاق القائمة" : "Close navigation"}
          >
            ×
          </button>
        </div>

        <nav className="admin-primary-nav">
          {items.map(([href, ar, en]) => {
            const active = pathActive(current, href);
            return (
              <a
                key={href}
                href={href}
                className={active ? "active" : ""}
                aria-current={active ? "page" : undefined}
                onClick={closeMobileNav}
              >
                <span className="admin-nav-marker" aria-hidden="true" />
                <span>{lang === "ar" ? ar : en}</span>
              </a>
            );
          })}
        </nav>

        {isSuperadmin && (
          <div className="kb-subnav">
            <div className="admin-nav-section-label">{lang === "ar" ? "إدارة قاعدة المعرفة" : "Knowledge management"}</div>
            {knowledgeItems.map(([href, ar, en]) => {
              const active = pathActive(current, href);
              return (
                <a key={href} href={href} className={active ? "active" : ""} aria-current={active ? "page" : undefined} onClick={closeMobileNav}>
                  {lang === "ar" ? ar : en}
                </a>
              );
            })}
          </div>
        )}

        <div className="admin-sidebar-footer">
          <strong>{user.username}</strong>
          <span>{isSuperadmin ? "SUPERADMIN" : (user.memberships?.[0]?.roleKey || "TENANT USER")}</span>
        </div>
      </aside>

      <div className="admin-main">
        <header className="admin-topbar">
          <div className="admin-topbar-start">
            <button
              className="admin-mobile-menu"
              type="button"
              onClick={() => setMobileNavOpen(true)}
              aria-expanded={mobileNavOpen}
              aria-label={lang === "ar" ? "فتح القائمة" : "Open navigation"}
            >
              <span />
              <span />
              <span />
            </button>
            <div className="admin-page-context">
              <span>{lang === "ar" ? "TCRM مركز المساعدة" : "TCRM Help Center"}</span>
              <strong>{currentTitle}</strong>
            </div>
          </div>

          <div className="admin-topbar-actions">
            <ThemeToggle lang={lang} />
            <button className="toolbar-btn" type="button" onClick={() => setLang(lang === "ar" ? "en" : "ar")}>
              {lang === "ar" ? "English" : "العربية"}
            </button>
            <button className="toolbar-btn" type="button" onClick={onLogout}>
              {lang === "ar" ? "تسجيل الخروج" : "Sign out"}
            </button>
          </div>
        </header>

        <main className="admin-content">{children}</main>
      </div>

      <TamyFloatingAgent lang={lang} />
    </div>
  );
}
"""
TAMY_CONTENT = r"""import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import type { Language } from "../i18n/translations";
import { AiSupportAgent } from "./SupportWidgets";

type DockSide = "left" | "right";
type Point = { x: number; y: number };

const POSITION_KEY = "tcrmhc.tamy.position";
const DOCK_KEY = "tcrmhc.tamy.dock";
const FAB_SIZE = 72;
const EDGE_GAP = 16;

function clampPoint(point: Point): Point {
  if (typeof window === "undefined") return point;
  const maxX = Math.max(EDGE_GAP, window.innerWidth - FAB_SIZE - EDGE_GAP);
  const maxY = Math.max(EDGE_GAP, window.innerHeight - FAB_SIZE - EDGE_GAP);
  return {
    x: Math.min(Math.max(point.x, EDGE_GAP), maxX),
    y: Math.min(Math.max(point.y, EDGE_GAP), maxY)
  };
}

function defaultPoint(): Point {
  if (typeof window === "undefined") return { x: EDGE_GAP, y: 160 };
  return clampPoint({
    x: window.innerWidth - FAB_SIZE - 24,
    y: Math.max(120, Math.round(window.innerHeight * 0.62))
  });
}

function readPosition(): Point {
  if (typeof window === "undefined") return defaultPoint();
  try {
    const value = JSON.parse(window.localStorage.getItem(POSITION_KEY) || "null") as Point | null;
    if (value && Number.isFinite(value.x) && Number.isFinite(value.y)) return clampPoint(value);
  } catch {
    // Ignore malformed legacy preference.
  }
  return defaultPoint();
}

function readDock(): DockSide {
  if (typeof window === "undefined") return "right";
  return window.localStorage.getItem(DOCK_KEY) === "left" ? "left" : "right";
}

function SparkIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
      <path d="M12 2.8 13.8 8l5.2 1.8-5.2 1.8L12 17l-1.8-5.4L5 9.8 10.2 8 12 2.8Z" />
      <path d="m18.2 15 .8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2Z" />
    </svg>
  );
}

export function TamyFloatingAgent({ lang }: { lang: Language }) {
  const [open, setOpen] = useState(false);
  const [dock, setDock] = useState<DockSide>(() => readDock());
  const [position, setPosition] = useState<Point>(() => readPosition());
  const drag = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    moved: boolean;
  } | null>(null);

  useEffect(() => {
    const onResize = () => {
      setPosition((current) => {
        const next = clampPoint(current);
        window.localStorage.setItem(POSITION_KEY, JSON.stringify(next));
        return next;
      });
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    if (!open) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [open]);

  const onPointerDown = (event: ReactPointerEvent<HTMLButtonElement>) => {
    if (event.button !== 0) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    drag.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: position.x,
      originY: position.y,
      moved: false
    };
  };

  const onPointerMove = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const state = drag.current;
    if (!state || state.pointerId !== event.pointerId) return;
    const dx = event.clientX - state.startX;
    const dy = event.clientY - state.startY;
    if (Math.abs(dx) + Math.abs(dy) > 5) state.moved = true;
    setPosition(clampPoint({ x: state.originX + dx, y: state.originY + dy }));
  };

  const finishPointer = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const state = drag.current;
    if (!state || state.pointerId !== event.pointerId) return;
    const moved = state.moved;
    drag.current = null;
    try {
      event.currentTarget.releasePointerCapture(event.pointerId);
    } catch {
      // Capture may already be released by the browser.
    }
    window.localStorage.setItem(POSITION_KEY, JSON.stringify(position));
    if (!moved) setOpen((value) => !value);
  };

  const switchDock = () => {
    const next: DockSide = dock === "right" ? "left" : "right";
    setDock(next);
    window.localStorage.setItem(DOCK_KEY, next);
  };

  const dockLabel = dock === "right"
    ? (lang === "ar" ? "نقل تامي لليسار" : "Move Tamy left")
    : (lang === "ar" ? "نقل تامي لليمين" : "Move Tamy right");

  return (
    <div className="tamy-root">
      {open && <button className="tamy-mobile-scrim" type="button" aria-label={lang === "ar" ? "إغلاق تامي" : "Close Tamy"} onClick={() => setOpen(false)} />}

      {open && (
        <aside className={`tamy-panel dock-${dock}`} aria-label={lang === "ar" ? "تامي المساعد الذكي" : "Tamy AI assistant"}>
          <header className="tamy-panel-header">
            <div className="tamy-identity">
              <span className="tamy-avatar" aria-hidden="true"><SparkIcon /></span>
              <div>
                <strong>Tamy</strong>
                <span>{lang === "ar" ? "المساعد الذكي لمركز المساعدة" : "Help Center AI assistant"}</span>
              </div>
            </div>
            <div className="tamy-panel-actions">
              <button className="tamy-icon-btn" type="button" onClick={switchDock} title={dockLabel} aria-label={dockLabel}>
                {dock === "right" ? "←" : "→"}
              </button>
              <button className="tamy-icon-btn" type="button" onClick={() => setOpen(false)} aria-label={lang === "ar" ? "إغلاق تامي" : "Close Tamy"}>
                ×
              </button>
            </div>
          </header>
          <div className="tamy-panel-body">
            <AiSupportAgent lang={lang} />
          </div>
        </aside>
      )}

      <button
        className={`tamy-fab${open ? " is-open" : ""}`}
        type="button"
        style={{ left: `${position.x}px`, top: `${position.y}px` }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={finishPointer}
        onPointerCancel={() => { drag.current = null; }}
        onClick={(event) => { if (event.detail === 0) setOpen((value) => !value); }}
        aria-expanded={open}
        aria-label={open ? (lang === "ar" ? "إغلاق تامي" : "Close Tamy") : (lang === "ar" ? "فتح تامي" : "Open Tamy")}
        title={lang === "ar" ? "تامي — اسحب لتحريكها" : "Tamy — drag to move"}
      >
        <span className="tamy-fab-icon"><SparkIcon /></span>
        <span className="tamy-fab-name">Tamy</span>
      </button>
    </div>
  );
}
"""
CSS = r"""/* TCRMHC UX/UI Phase 2 — Application Shell + Tamy Floating Agent */

.admin-shell {
  --admin-sidebar-width: 270px;
  grid-template-columns: var(--admin-sidebar-width) minmax(0, 1fr);
  background: var(--ui-bg);
}

.admin-main {
  min-height: 100vh;
  background: transparent;
}

.admin-sidebar {
  height: 100vh;
  overflow: hidden;
  border-inline-end: 1px solid var(--ui-border);
  background: var(--ui-sidebar);
  box-shadow: 10px 0 32px rgba(0, 0, 0, .035);
}

[dir="rtl"] .admin-sidebar {
  box-shadow: -10px 0 32px rgba(0, 0, 0, .035);
}

.admin-sidebar-head {
  position: relative;
  flex: 0 0 auto;
}

.admin-sidebar-close {
  display: none;
}

.admin-primary-nav {
  overflow-y: auto;
  min-height: 0;
  padding-inline: 2px;
  scrollbar-width: thin;
  scrollbar-color: var(--ui-border-strong) transparent;
}

.admin-primary-nav a {
  position: relative;
  display: flex;
  align-items: center;
  gap: 11px;
  min-height: 45px;
  padding: 0 13px;
  color: var(--ui-text-secondary);
  border: 1px solid transparent;
  border-radius: 11px;
  text-decoration: none;
  transition: background var(--ui-transition), border-color var(--ui-transition), color var(--ui-transition), transform var(--ui-transition);
}

.admin-primary-nav a:hover {
  color: var(--ui-text);
  border-color: var(--ui-border);
  background: color-mix(in srgb, var(--ui-surface-raised) 70%, transparent);
  transform: translateX(2px);
}

[dir="rtl"] .admin-primary-nav a:hover {
  transform: translateX(-2px);
}

.admin-primary-nav a.active {
  color: var(--ui-text);
  border-color: var(--ui-accent-border);
  background: linear-gradient(135deg, var(--ui-accent-soft), color-mix(in srgb, var(--ui-surface-raised) 82%, transparent));
  box-shadow: inset 0 1px 0 color-mix(in srgb, white 6%, transparent);
}

.admin-nav-marker {
  width: 7px;
  height: 7px;
  flex: 0 0 auto;
  border: 1px solid var(--ui-border-strong);
  border-radius: 50%;
  background: transparent;
  transition: all var(--ui-transition);
}

.admin-primary-nav a.active .admin-nav-marker {
  border-color: var(--ui-accent);
  background: var(--ui-accent);
  box-shadow: 0 0 0 4px var(--ui-accent-soft);
}

.kb-subnav {
  flex: 0 0 auto;
  margin-top: 14px;
  border-color: var(--ui-border);
  background: color-mix(in srgb, var(--ui-surface) 55%, transparent);
}

.admin-nav-section-label {
  padding: 4px 8px 8px;
  color: var(--ui-text-tertiary);
  font-size: .68rem;
  font-weight: 800;
  letter-spacing: .08em;
  text-transform: uppercase;
}

.kb-subnav a {
  border-radius: 8px;
  transition: color var(--ui-transition), background var(--ui-transition);
}

.kb-subnav a.active {
  color: var(--ui-accent-text);
  background: var(--ui-accent-soft);
}

.admin-sidebar-footer {
  background: color-mix(in srgb, var(--ui-surface) 48%, transparent);
  border-radius: 12px;
  margin-top: auto;
}

.admin-topbar {
  min-height: 72px;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 11px 28px;
  border-bottom: 1px solid var(--ui-border);
  background: var(--ui-topbar);
  backdrop-filter: blur(18px) saturate(140%);
  box-shadow: 0 1px 0 var(--ui-border), 0 12px 32px rgba(0, 0, 0, .035);
}

.admin-topbar-start,
.admin-topbar-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.admin-topbar-actions {
  justify-content: flex-end;
  flex-wrap: wrap;
}

.admin-page-context {
  display: grid;
  gap: 2px;
  min-width: 0;
}

.admin-page-context > span {
  color: var(--ui-text-tertiary);
  font-size: .72rem;
  font-weight: 700;
}

.admin-page-context > strong {
  max-width: 420px;
  overflow: hidden;
  color: var(--ui-text);
  font-size: .98rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.admin-mobile-menu {
  display: none;
  width: 44px;
  height: 44px;
  place-items: center;
  gap: 4px;
  padding: 11px;
  border: 1px solid var(--ui-border);
  border-radius: 11px;
  color: var(--ui-text);
  background: var(--ui-surface);
  cursor: pointer;
}

.admin-mobile-menu span {
  display: block;
  width: 20px;
  height: 2px;
  border-radius: 999px;
  background: currentColor;
}

.admin-sidebar-scrim {
  display: none;
}

.admin-content {
  width: 100%;
  max-width: 1540px;
  padding: 30px clamp(20px, 3vw, 38px) 48px;
}

/* Tamy */
.tamy-root {
  position: relative;
  z-index: 70;
}

.tamy-fab {
  position: fixed;
  z-index: 74;
  width: 72px;
  height: 72px;
  display: grid;
  grid-template-rows: 1fr auto;
  place-items: center;
  gap: 1px;
  padding: 10px 8px 8px;
  border: 1px solid var(--ui-accent-border);
  border-radius: 22px;
  color: #211704;
  background: linear-gradient(145deg, #f7d873 0%, #d6a122 58%, #b77b08 100%);
  box-shadow: 0 18px 38px rgba(0, 0, 0, .22), 0 0 0 5px color-mix(in srgb, var(--ui-accent) 8%, transparent), inset 0 1px 0 rgba(255,255,255,.55);
  cursor: grab;
  touch-action: none;
  user-select: none;
  transition: box-shadow var(--ui-transition), transform var(--ui-transition), filter var(--ui-transition);
}

.tamy-fab:hover {
  transform: translateY(-2px) scale(1.02);
  box-shadow: 0 22px 46px rgba(0, 0, 0, .26), 0 0 0 7px color-mix(in srgb, var(--ui-accent) 10%, transparent), inset 0 1px 0 rgba(255,255,255,.6);
}

.tamy-fab:active {
  cursor: grabbing;
  transform: scale(.98);
}

.tamy-fab.is-open {
  box-shadow: 0 20px 48px rgba(0,0,0,.28), 0 0 0 7px color-mix(in srgb, var(--ui-accent) 14%, transparent);
}

.tamy-fab-icon {
  display: grid;
  place-items: center;
}

.tamy-fab-icon svg {
  width: 27px;
  height: 27px;
}

.tamy-fab-name {
  font-size: .69rem;
  font-weight: 900;
  letter-spacing: .03em;
}

.tamy-panel {
  position: fixed;
  z-index: 72;
  top: 92px;
  bottom: 22px;
  width: min(430px, calc(100vw - 34px));
  display: flex;
  flex-direction: column;
  overflow: hidden;
  color: var(--ui-text);
  border: 1px solid var(--ui-border-strong);
  border-radius: 20px;
  background: color-mix(in srgb, var(--ui-surface-raised) 95%, transparent);
  box-shadow: 0 28px 80px rgba(0, 0, 0, .28);
  backdrop-filter: blur(22px) saturate(135%);
  animation: tamy-panel-in 180ms cubic-bezier(.2,.8,.2,1);
}

.tamy-panel.dock-right {
  right: 22px;
}

.tamy-panel.dock-left {
  left: 22px;
}

.tamy-panel-header {
  min-height: 72px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 14px 12px 16px;
  border-bottom: 1px solid var(--ui-border);
  background: linear-gradient(135deg, var(--ui-accent-soft), transparent 55%);
}

.tamy-identity {
  display: flex;
  align-items: center;
  gap: 11px;
  min-width: 0;
}

.tamy-avatar {
  width: 42px;
  height: 42px;
  display: grid;
  flex: 0 0 auto;
  place-items: center;
  border: 1px solid var(--ui-accent-border);
  border-radius: 13px;
  color: #211704;
  background: linear-gradient(145deg, #f7d873, #d6a122);
  box-shadow: var(--ui-shadow-sm);
}

.tamy-avatar svg {
  width: 22px;
  height: 22px;
}

.tamy-identity > div {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.tamy-identity strong {
  color: var(--ui-text);
  font-size: 1.04rem;
}

.tamy-identity span {
  overflow: hidden;
  color: var(--ui-text-secondary);
  font-size: .75rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.tamy-panel-actions {
  display: flex;
  gap: 6px;
}

.tamy-icon-btn {
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border: 1px solid var(--ui-border);
  border-radius: 10px;
  color: var(--ui-text);
  background: var(--ui-surface);
  cursor: pointer;
  transition: all var(--ui-transition);
}

.tamy-icon-btn:hover {
  border-color: var(--ui-accent-border);
  background: var(--ui-accent-soft);
}

.tamy-panel-body {
  min-height: 0;
  flex: 1;
  overflow: hidden;
  padding: 14px;
}

.tamy-panel .ai-support-agent {
  height: 100%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: 0;
  background: transparent;
  box-shadow: none;
}

.tamy-panel .ai-support-header {
  display: none;
}

.tamy-panel .ai-chat-log {
  min-height: 0;
  flex: 1;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 4px;
}

.tamy-panel .ai-chat-form {
  flex: 0 0 auto;
  margin-top: 10px;
}

.tamy-panel .empty-state {
  padding: 28px 16px;
}

.tamy-mobile-scrim {
  display: none;
}

@keyframes tamy-panel-in {
  from {
    opacity: 0;
    transform: translateY(8px) scale(.985);
  }
  to {
    opacity: 1;
    transform: none;
  }
}

@media (max-width: 980px) {
  body.admin-nav-open {
    overflow: hidden;
  }

  .admin-shell {
    display: block;
    min-height: 100vh;
  }

  .admin-sidebar {
    position: fixed;
    z-index: 90;
    top: 0;
    bottom: 0;
    left: 0;
    right: auto;
    width: min(320px, 88vw);
    height: 100dvh;
    min-height: 0;
    padding: 18px 14px;
    border: 0;
    border-inline-end: 1px solid var(--ui-border);
    transform: translateX(-104%);
    transition: transform 220ms cubic-bezier(.2,.8,.2,1);
    box-shadow: 24px 0 70px rgba(0,0,0,.28);
  }

  [dir="rtl"] .admin-sidebar {
    right: 0;
    left: auto;
    border-inline-end: 0;
    border-inline-start: 1px solid var(--ui-border);
    transform: translateX(104%);
    box-shadow: -24px 0 70px rgba(0,0,0,.28);
  }

  .admin-sidebar.mobile-open,
  [dir="rtl"] .admin-sidebar.mobile-open {
    transform: translateX(0);
  }

  .admin-sidebar-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 8px;
  }

  .admin-brand {
    flex: 1;
    flex-direction: row;
    justify-content: flex-start;
    padding: 4px 6px 18px;
  }

  .admin-brand img {
    width: 84px;
    max-height: 64px;
  }

  .admin-sidebar-close {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    border: 1px solid var(--ui-border);
    border-radius: 11px;
    color: var(--ui-text);
    background: var(--ui-surface);
    font-size: 1.6rem;
    line-height: 1;
    cursor: pointer;
  }

  .admin-primary-nav {
    display: grid;
    grid-template-columns: 1fr;
    gap: 6px;
  }

  .kb-subnav {
    overflow-y: auto;
    max-height: 37vh;
  }

  .admin-sidebar-footer {
    display: grid;
  }

  .admin-sidebar-scrim {
    position: fixed;
    z-index: 89;
    inset: 0;
    display: block;
    border: 0;
    padding: 0;
    background: rgba(0,0,0,.48);
    backdrop-filter: blur(2px);
    opacity: 0;
    pointer-events: none;
    transition: opacity 180ms ease;
  }

  .admin-shell.mobile-nav-open .admin-sidebar-scrim {
    opacity: 1;
    pointer-events: auto;
  }

  .admin-topbar {
    position: sticky;
    top: 0;
    z-index: 40;
    min-height: 66px;
    padding: 9px 16px;
  }

  .admin-mobile-menu {
    display: grid;
  }

  .admin-content {
    padding: 24px 18px 42px;
  }
}

@media (max-width: 620px) {
  .admin-topbar {
    gap: 10px;
    padding-inline: 12px;
  }

  .admin-page-context > span {
    display: none;
  }

  .admin-page-context > strong {
    max-width: 132px;
    font-size: .88rem;
  }

  .admin-topbar-actions {
    gap: 6px;
  }

  .admin-topbar .toolbar-btn {
    min-height: 40px;
    padding-inline: 10px;
    font-size: .78rem;
  }

  .admin-topbar .theme-toggle {
    width: 40px;
    padding: 0;
  }

  .admin-topbar .theme-toggle span {
    display: none;
  }

  .admin-content {
    padding: 20px 12px 34px;
  }

  .tamy-panel {
    z-index: 96;
    inset: 70px 10px 10px 10px !important;
    width: auto;
    max-height: none;
    border-radius: 18px;
  }

  .tamy-panel-header {
    min-height: 66px;
    padding: 10px 11px;
  }

  .tamy-panel-body {
    padding: 10px;
  }

  .tamy-mobile-scrim {
    position: fixed;
    z-index: 95;
    inset: 0;
    display: block;
    border: 0;
    background: rgba(0,0,0,.44);
    backdrop-filter: blur(2px);
  }
}

html[data-theme="light"] .admin-sidebar,
html[data-theme="light"] .admin-topbar,
html[data-theme="light"] .tamy-panel {
  box-shadow-color: rgba(31,48,73,.12);
}

@media (prefers-reduced-motion: reduce) {
  .admin-sidebar,
  .admin-sidebar-scrim,
  .tamy-panel,
  .tamy-fab {
    animation: none !important;
    transition: none !important;
  }
}"""

def fail(message: str):
    raise SystemExit(f"ERROR: {message}")

def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()

if not (ROOT / "package.json").exists() or not ADMIN.exists() or not STYLES.exists():
    fail("run from the TCRMHC repository root")

styles = STYLES.read_text(encoding="utf-8")
if MARKER in styles and TAMY.exists():
    print("TCRMHC UX/UI Phase 2 already appears applied; no changes made.")
    raise SystemExit(0)

head = git("rev-parse", "HEAD")
if head != BASE_COMMIT:
    fail(f"unexpected TCRMHC HEAD {head}; patch was prepared against {BASE_COMMIT}. Preserve current work and stop for rebase/review.")

if PHASE11_MARKER not in styles:
    fail("Phase 1.1 light-login marker not found; Phase 2 prerequisite is missing")

status = git("status", "--porcelain")
if status:
    fail("worktree is not clean. Do not discard existing changes; review/preserve them before applying Phase 2.")

stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
backup_root = ROOT / ".patch-backups" / f"uxui-phase2-{stamp}"
for path in (ADMIN, TAMY, STYLES):
    if path.exists():
        target = backup_root / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

ADMIN.write_text(ADMIN_CONTENT, encoding="utf-8")
TAMY.parent.mkdir(parents=True, exist_ok=True)
TAMY.write_text(TAMY_CONTENT, encoding="utf-8")
STYLES.write_text(styles.rstrip() + "\n\n" + CSS + "\n", encoding="utf-8")

print("Applied TCRMHC UX/UI Phase 2 — Application Shell + Tamy Floating Agent.")
print(f"Backup: {backup_root}")
print("Changed:")
print("- apps/web/src/features/admin/AdminLayout.tsx")
print("- apps/web/src/features/TamyFloatingAgent.tsx")
print("- apps/web/src/styles.css")
